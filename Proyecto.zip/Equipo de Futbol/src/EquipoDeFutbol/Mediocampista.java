package EquipoDeFutbol;

public class Mediocampista extends Jugador{
    private int asistenciasRealizadas;

    public Mediocampista(String nombre, String apellidos, int edad, boolean esTitular, int asistenciasRealizadas) {
        super(nombre, apellidos, edad, esTitular);
        this.asistenciasRealizadas = asistenciasRealizadas;
    }

    public int getAsistenciasRealizadas() {
        return asistenciasRealizadas;
    }

    public void setAsistenciasRealizadas(int asistenciasRealizadas) {
        this.asistenciasRealizadas = asistenciasRealizadas;
    }
}
