package EquipoDeFutbol;

public class Entrenador extends Persona{

    protected int aniosDeExperiencia;
    protected boolean esNacional;

    public Entrenador(String nombre, String apellidos, int edad, int aniosDeExperiencia, boolean esNacional) {
        super(nombre, apellidos, edad);
        this.aniosDeExperiencia = aniosDeExperiencia;
        this.esNacional = esNacional;
    }

    public int getAniosDeExperiencia() {
        return aniosDeExperiencia;
    }

    public void setAniosDeExperiencia(int aniosDeExperiencia) {
        this.aniosDeExperiencia = aniosDeExperiencia;
    }

    public boolean isEsNacional() {
        return esNacional;
    }

    public void setEsNacional(boolean esNacional) {
        this.esNacional = esNacional;
    }


}
