package EquipoDeFutbol;

import java.util.LinkedList;
import java.util.List;
import EquipoDeFutbol.*;

public class EquipoDeFutbol {
    private String nombre;
    private String pais;
    private Entrenador entrenador;
    private Portero portero;
    private List<Defensa> defensas;
    private List<Mediocampista> mediocampistas;
    private List<Delantero> delanteros;

    private EquipoDeFutbol(String nombre, String pais){
        this.nombre = nombre;
        this.pais = pais;
    }

    public EquipoDeFutbol(String nombre, String pais, Entrenador entrenador, Portero portero, List<Defensa> defensas, List<Mediocampista> mediocampistas, List<Delantero> delanteros) {
        this(nombre, pais);
        this.entrenador = entrenador;
        this.portero = portero;
        this.defensas = defensas;
        this.mediocampistas = mediocampistas;
        this.delanteros = delanteros;
    }

    public void mostrarInformacionDelEquipo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "EquipoDeFutbol:" + '\n' +
                "nombre= " + nombre + '\n' +
                "pais= " + pais + '\n' +
                "entrenador= " + entrenador + '\n' +
                "portero= " + portero + '\n' +
                "defensas= " + defensas + '\n' +
                "mediocampistas= " + mediocampistas + '\n' +
                "delanteros= " + delanteros + '\n';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public Entrenador getEntrenador() {
        return entrenador;
    }

    public void setEntrenador(Entrenador entrenador) {
        this.entrenador = entrenador;
    }

    public Portero getPortero() {
        return portero;
    }

    public void setPortero(Portero portero) {
        this.portero = portero;
    }

    public List<Defensa> getDefensas() {
        return defensas;
    }

    public void setDefensas(List<Defensa> defensas) {
        this.defensas = defensas;
    }

    public List<Mediocampista> getMediocampistas() {
        return mediocampistas;
    }

    public void setMediocampistas(List<Mediocampista> mediocampistas) {
        this.mediocampistas = mediocampistas;
    }

    public List<Delantero> getDelanteros() {
        return delanteros;
    }

    public void setDelanteros(List<Delantero> delanteros) {
        this.delanteros = delanteros;
    }
}
