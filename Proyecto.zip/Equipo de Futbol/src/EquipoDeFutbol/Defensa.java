package EquipoDeFutbol;

public class Defensa extends Jugador{

    public Defensa(String nombre, String apellidos, int edad, boolean esTitular) {
        super(nombre, apellidos, edad, esTitular);
    }
}
