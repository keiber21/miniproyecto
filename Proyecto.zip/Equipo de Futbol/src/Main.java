import EquipoDeFutbol.*;

import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String nombre = "Seleccion de Colombia";
        String pais = "Colombia";

        Entrenador entrenador = new Entrenador("Carlos", "Queiroz", 66, 30, false);

        Portero portero = new Portero("David", "Ospina", 66, true, 10);

        List<Defensa> defensas = new LinkedList<Defensa>();
        defensas.add(new Defensa("Jerry", "Mina", 24, true));
        defensas.add(new Defensa("Davinson", "Sanchez", 23, true));
        defensas.add(new Defensa("William", "Tesillo", 29, true));
        defensas.add(new Defensa("Stefan", "Medina", 29, true));

        List<Mediocampista> mediocampistas = new LinkedList<Mediocampista>();
        mediocampistas.add(new Mediocampista("Mateus", "Uribe", 28, true, 12));
        mediocampistas.add(new Mediocampista("Wilmer", "Barrios", 25, true, 12));
        mediocampistas.add(new Mediocampista("Juan Guillermo", "Cuadrado", 31, true, 10));
        mediocampistas.add(new Mediocampista("James", "Rodriguez", 28, true, 32));

        List<Delantero> delanteros = new LinkedList<Delantero>();
        delanteros.add(new Delantero("Radamel Falcao", "Garcia", 33, true, 15));
        delanteros.add(new Delantero("Duvan Zapata", "Garcia", 28, true, 12));

        EquipoDeFutbol equipoDeFutbol = new EquipoDeFutbol(nombre, pais, entrenador, portero, defensas, mediocampistas, delanteros);

        equipoDeFutbol.mostrarInformacionDelEquipo();
    }
}