package MatchDeportivo;

public class PartidoFutbolLigaEspanola implements PartidoDeFutbol{

    private String equipoLocal;
    private String equipoVisitante;

    private int golesEquipoLocal;
    private int golesEquipoVisitante;


    @Override
    public void SetGolesEquipoLocal(int marcador) {
        golesEquipoLocal = marcador;
    }

    @Override
    public void SetGolesEquipoVisitante(int marcador) {
        golesEquipoVisitante = marcador;
    }

    @Override
    public void setEquipoLocal(String nombreEquipo) {
        equipoLocal = nombreEquipo;
    }

    @Override
    public void setEquipoVisitante(String nombreEquipo) {
        equipoVisitante = nombreEquipo;
    }

    public void imprimirMarcador(){
        System.out.println(equipoLocal + golesEquipoLocal + " : " + golesEquipoVisitante + equipoVisitante);
    }

    public String getEquipoLocal() {
        return equipoLocal;
    }

    public String getEquipoVisitante() {
        return equipoVisitante;
    }

    public int getGolesEquipoLocal() {
        return golesEquipoLocal;
    }

    public int getGolesEquipoVisitante() {
        return golesEquipoVisitante;
    }
}
