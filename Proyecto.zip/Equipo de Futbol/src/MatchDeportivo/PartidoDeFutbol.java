package MatchDeportivo;

public interface PartidoDeFutbol extends MatchDeportivo{

    final int duracionDelPartido = 90;
    public void SetGolesEquipoLocal(int marcador);
    public void SetGolesEquipoVisitante(int marcador);
}
