package MatchDeportivo;

public interface PartidoDeBaloncesto extends MatchDeportivo{

    final int duracionDelPartido = 40;
    public void SetCestasEquipoLocal(int marcador);
    public void SetCestasEquipoVisitante(int marcador);
}
