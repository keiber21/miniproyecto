package MatchDeportivo;

public interface MatchDeportivo {
    public void setEquipoLocal(String nombreEquipo);
    public void setEquipoVisitante(String nombreEquipo);
}
